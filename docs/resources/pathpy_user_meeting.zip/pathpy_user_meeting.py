#%%
import pathpy as pp
import sqlite3
import json
from collections import defaultdict

import pandas as pd
import seaborn as sns
sns.set()

#%% Showcase: Interactive visualisation in jupyter
##################################################
t = pp.TemporalNetwork.read_file('lotr.tedges', directed=False)
t


#%% Showcase: offline visualisation
###################################
pp.visualisation.plot(t, d3js_path = 'http://localhost:8888/notebooks/d3.v4.min.js',)


#%% Showcase: Visualisation Templates
#####################################

# Load chapter marks from JSON file
with open('chapters.json', 'r') as f:
    chapters = json.load(f)

# Load character classes from JSON file
with open('characters.json', 'r') as f:
    characters = json.load(f)

style = {
    # some default parameters
    'width': 1200,
    'height': 1000,
    'look_ahead': 500,
    'look_behind': 1500,
    'ts_per_frame': 20, 
    'ms_per_frame': 50,
    'inactive_edge_width': 4.0,
    'active_edge_width': 6.0,
    'label_offset': [0,-16],    
    'node_size': 10,
    'label_size': '14px',
    
     # tell pathpy to use a user-provided custom template
    'template': 'custom_template.html',
    
    # add custom parameters defined in our custom template
    'chapter_data': chapters, 
    'character_classes': characters,    
}

# generate HTML based on our custom template
pp.visualisation.export_html(t, filename='template_demo.html', **style)


#%% Showcase: Database support
##############################
con = sqlite3.connect('temporal_networks.db')
con.row_factory = sqlite3.Row

t_data = pp.TemporalNetwork.from_sqlite(
    con.execute('SELECT source, target, time FROM example'))
print(t_data)


#%% Showcase: Time remapping
############################
dag, node_map = pp.DAG.from_temporal_network(t_data, delta=20)
print(dag)

#%%
t_data = pp.TemporalNetwork.from_sqlite(
    con.execute('SELECT source, target, time FROM example'), time_rescale=20)
print(t_data)

#%%
dag, node_map = pp.DAG.from_temporal_network(t_data, delta=1)
print(dag)


#%% Showcase: Time-slice analysis
#################################
data = defaultdict(list)

for n, w in pp.RollingTimeWindow(t_data, window_size=180, step_size=180, directed=False, return_window=True):
    data['nodes'].append(n.ncount())
    data['links'].append(n.ecount())
    data['time'].append(w[0])

# %% Plot time-variable network measures
df = pd.DataFrame(data, columns=list(data.keys()))
sns.relplot(x='time', markers=True, kind='line', data=df, y='links')


#%% Showcase: Network models
############################
style = {
    'node_size' :  10.0,
    'node_color' : '#555555',
    'label_offset' : [0,0],
    'label_color' : 'white',
    'look_behind' : 1000,
    'look_ahead' : 0,
    'ms_per_frame' : 250,
    'width' : 800,
    'height' : 800
}

ds = [5]*50
n = pp.algorithms.random_graphs.molloy_reed(ds, self_loops=False)
pp.visualisation.plot(n, **style)

#%%
n = pp.algorithms.random_graphs.erdoes_renyi_gnm(100, 200)
pp.visualisation.plot(n, **style)

#%%
n = pp.algorithms.random_graphs.barabasi_albert(200, 5)
pp.visualisation.plot(n, **style)

#%%
n = pp.algorithms.random_graphs.barabasi_albert(200, 5, temporal=True)
pp.visualisation.plot(n, **style)